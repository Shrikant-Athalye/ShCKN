import cv2
import os
from scipy.stats import kurtosis
from scipy import stats
import numpy as np
import LGBP,sparking,bas_clus,CNN
import DKN
Acc, Sen, Spe, Mcc = [], [], [], []
feat,lab,inp,op = [], [], [], []
path = r'Data'  # dataset folder path
lst = os.listdir(path)  # list of images from the folder
for i in range(len(lst)):
    ll = (os.path.splitext(lst[i])[0]).split('_')[-1]
    if ll == 'dr': lab.append(2)
    elif ll == 'g': lab.append(1)
    else: lab.append(0)
    img_ = path + '/' + lst[i]   # path of image
    img = cv2.imread(img_)       # read the image
    img = cv2.resize(img,(256,256))
    im_hist = (cv2.calcHist([img], [0], None, [300], [0, 300])).flatten()
    inp.append(im_hist)

#------------------------preprocessing using gaussian filter-------------------------

    processed = cv2.GaussianBlur(img, (5, 5), cv2.BORDER_DEFAULT)

#---------------------------------segmentation---------------------------------------
# optic disc segmentation using bayesian fuzzy clustering
    op_seg = bas_clus.BFCM(processed)
    optic = (cv2.calcHist([op_seg], [0], None, [300], [0, 300])).flatten()
    op.append(optic)

# blood vessel detection using sparking process
    seg_blood = sparking.net_process(processed)
#------------------------------Feature extraction------------------------------------

# LGBP
    f1,_ = LGBP.lgbp(op_seg)
    f11,_ = LGBP.lgbp(seg_blood)

# statistical features
    f2 = op_seg.mean()
    f12 = seg_blood.mean()
    f3 = np.var(op_seg)
    f13 = np.var(seg_blood)
    f4 = np.std(op_seg)
    f14 = np.std(seg_blood)
    f5 = np.mean(stats.skew(op_seg))
    f15 = np.mean(stats.skew(seg_blood))
    f6 = stats.entropy(op_seg.flatten())
    f16 = stats.entropy(seg_blood.flatten())
    f7 = np.mean(kurtosis(op_seg, axis=0, bias=True))
    f17 = np.mean(kurtosis(seg_blood, axis=0, bias=True))

# CNN features
    f8 = CNN.CNN_based(op_seg)[:100]
    f18 = CNN.CNN_based(seg_blood)[:100]

    F1 = list(np.concatenate((f1, f11)))
    F2 = (f2, f12, f3, f13, f4, f14, f5, f15, f6, f16, f7, f17)
    F3 = np.concatenate((f8, f18))
    F1.extend(F2)
    F1.extend(F3)
    feat.append(F1)

data = np.array(feat)
target = np.array(lab)
op = np.array(op)
inp = np.array(inp)

#-------------------------------Proposed----------------------------------

DKN.algm(data,target,op,inp,tr,Acc, Sen, Spe, Mcc)



