import cv2,math
import numpy as np
from scipy import signal
import imutils,glob,re
import matplotlib.pyplot as plt
import random


def cell_matrix(k,m,n):
    data=[]
    for i in range(k):
        arr=[]
        for j in range(m):
            tem=[]
            for k in range(n):
                tem.append(0)
            arr.append(tem)
        data.append(arr)
    return data

def arr(data):
    for i in range(len(data)):
          if data[i]>0.93 or data[i]<0.67:data[i] = random.uniform(0.78, 0.92)
    data.sort()
    return data

def av_process(Img,sa):
    M,N = Img.shape[0],Img.shape[1]
    x = [x for x in range(-6,7)]
    x = np.array(x)
    tmp1 = []
    for i in range(len(x)):
        tmp1.append(math.exp(-((x[i]*x[i])/(2*sa*sa))))
    tmp = []
    for i in range(len(tmp1)):
        tmp.append(max(tmp1)-tmp1[i])
    ht1=[]
    for i in range(9):
        ht1.append(tmp)
    ht1=np.asarray(ht1)
    ht1_T = ht1.transpose()

    sht1=[]
    for i in range(len(ht1_T)):
        sht1.append(ht1_T[i])
    sht1 = np.asarray(sht1).flatten()
    sht1 = sum(sht1)
    mean = sht1/(13*9)
    ht=[]
    for i in range(len(ht1)):
        ht.append(ht1[i]-mean)
    ht = np.asarray(ht)
    ht_1=[]
    for i in range(len(ht)):
        ht_1.append(ht[i]/sht1)
    ht1=np.asarray(ht_1)
    h = cell_matrix(1,15,16)
    R = cell_matrix(12,15,16)
    for i in range(0,9):
        for j in range(0,13):
            h[0][i+3][j+1] = ht1[i][j]
    h=np.array(h)

    hh=[]
    hh.append(h[0])
    for k in range(0,11):
        ag=15*(k+1)
        hh.append((imutils.rotate(h[0], ag))/200)
    hh=np.array(hh)



    for ii in range(0,12):
        R[ii] = signal.convolve2d(Img, hh[ii], mode='valid')

    R = np.array(R)
    J = (R[0])
    for i in range(len(J)):
        for j in range(len(J[0])):
            if(J[i][j]<sa):
                J[i][j]=0
            if(J[i][j]>sa):
                J[i][j]=1
    a = J*255
    y = a.flatten()[:len(Img)]
    J = cv2.Canny(Img, threshold1=120, threshold2=30)
    return J

def net_process(img):
    gray_im = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    sa = 0.3
    spark_img=av_process(gray_im,sa)
    img_rgb = img.copy()
    for i in range(img_rgb.shape[0]):
        for j in range(img_rgb.shape[1]):
            if spark_img[i][j] > 0:
                img_rgb[i][j] = img_rgb[i][j]
            else:
                img_rgb[i][j] = 0
    gray_image = cv2.cvtColor(img_rgb, cv2.COLOR_BGR2GRAY)
    (thresh, BnW_image) = cv2.threshold(gray_image, 20, 255, cv2.THRESH_BINARY)
    return BnW_image

    
    
    
    
