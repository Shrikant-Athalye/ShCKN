import numpy as np
import keras
import pandas as pd
from keras.optimizers import Adam
from keras.models import Sequential
from keras.layers import Dense, Flatten, Conv2D, MaxPooling2D
from keras.layers import Conv2D as Shepard_CNN
from keras.layers import LeakyReLU
from sklearn.model_selection import train_test_split
import os
os.environ["PATH"] += os.pathsep +'./'

def main_SHCNN(X_train,X_test,Y_train,Y_test,training_pre):

    test_precentage = 1-training_pre
    train_X = X_train.reshape(-1, 1,X_train.shape[1], 1)
    test_X = X_test.reshape(-1, 1,X_train.shape[1], 1)
    train_X = train_X.astype('float32')
    test_X = test_X.astype('float32')
    train_X = train_X / train_X.max()
    test_X = test_X / train_X.max()
    batch_size = 128
    epochs = 100
    num_classes = np.unique(Y_train)
    num_classes = len(num_classes)

    Y_train = keras.utils.to_categorical(Y_train)
    Y_test = keras.utils.to_categorical(Y_test)

    train_X, valid_X, train_label, valid_label = train_test_split(train_X, Y_train, test_size=test_precentage,
    random_state=13)
    # X_train = np.resize(X_train, (X_train.shape[0], 32, 32, X_train.shape[1]))
    model=Sequential()
    model.add(Conv2D(32, kernel_size=(3, 3), activation='linear', input_shape=(1, X_train.shape[1],1), padding='same'))
    model.add(Shepard_CNN(64, kernel_size=(1, 1), activation='linear'))
    model.add(LeakyReLU(alpha=0.1))
    model.add(MaxPooling2D((2, 2), padding='same'))
    model.add(Flatten())
    model.add(Dense(32, activation = 'relu', input_dim = len(X_train[0])))
    model.add(Dense(units = num_classes))

    adam = Adam()
    model.compile(optimizer=adam, loss='mean_squared_error', metrics=['accuracy'])
    model.fit(train_X, train_label, batch_size=batch_size, epochs=epochs, verbose=0)
    test_eval_arr = model.predict(test_X)
    test_eval_arr.flatten()

    return test_eval_arr



def callmain(data,y1,training_pre):

    X_train, X_test, y_train, y_test = train_test_split(data,y1, train_size = training_pre)


    pred = main_SHCNN(np.array(X_train), np.array(X_test), np.array(y_train), np.array(y_test),training_pre)

    return pred





