import numpy as np
import pandas as pd
import tensorflow as tf
from sklearn.model_selection import train_test_split
from keras.layers import Input, Conv2D, Dense, Flatten, Reshape, Multiply
from keras.models import Model
import shcnn, shcnn_fuzzy_dkn

def algm(X,Y,seg,inp, tr,Acc,Sen,Spe,Mcc):
    l1 = shcnn.callmain(inp,Y,tr)
    l3 = shcnn_fuzzy_dkn.process(X,Y,l1,tr)
    data = np.column_stack((l3,seg))
    # Define the DKN-like model
    def create_dkn_model(input_shape):
        input_layer = Input(shape=input_shape)

        # Kronecker factored layer (Convolution)
        kronecker_conv1 = Conv2D(32, (3, 3), padding='same')(input_layer)
        kronecker_conv2 = Conv2D(32, (3, 3), padding='same')(input_layer)
        kronecker_layer = Multiply()([kronecker_conv1, kronecker_conv2])

        # Flatten the Kronecker factored layer
        flattened = Flatten()(kronecker_layer)

        # Fully connected layers
        fc1 = Dense(128, activation='relu')(flattened)
        output_layer = Dense(1, activation='softmax')(fc1) # Adjust the number of output classes

        # Create the model
        model = Model(inputs=input_layer, outputs=output_layer)

        return model

    X_train, X_test, y_train, y_test = train_test_split(data, Y, train_size=tr, random_state=42)

    input_shape = (28, 28, 1)

    # Create the DKN-like model
    model = create_dkn_model(input_shape)

    # Compile the model
    model.compile(optimizer='adam', loss='categorical_crossentropy', metrics=['accuracy'])

    X_train = np.resize(X_train,(len(X_train),28,28,1))
    X_test = np.resize(X_test,(len(X_test),28,28,1))
    model.fit(X_train, y_train, epochs=100, verbose=0)
    y_pred = model.predict(X_test)
    target = y_test
    unique_clas = np.unique(target)
    tp, tn, fn, fp = 0, 0, 0, 0
    for i1 in range(len(unique_clas)):
        c = unique_clas[i1]
        for i in range(len(target)):
            if (target[i] == c and y_pred[i] == c):
                tp = tp + 1
            if (target[i] != c and y_pred[i] != c):
                tn = tn + 1
            if (target[i] == c and y_pred[i] != c):
                fn = fn + 1
            if (target[i] != c and y_pred[i] == c):
                fp = fp + 1

    acc = (tp + tn) / (tp + tn + fp + fn)
    sen=(tp / (tp + fn))
    spe=(tn / (tn + fp))
    mcc = (tp * tn - fp * fn) / np.sqrt((tp + fp) * (tp + fn) * (tn + fp) * (tn + fn))
    Mcc.append(mcc)
    Sen.append(sen)
    Spe.append(spe)
    Acc.append(acc)