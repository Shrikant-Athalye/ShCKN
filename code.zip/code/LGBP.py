import cv2
import numpy as np


def lgbp(img):
    result = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)

    def get_pixel(img, center, x, y):
        new_value = 0
        try:
            if img[x][y] >= center:
                new_value = 1
        except:
            pass
        return new_value

    def lbp_calculated_pixel(img, x, y):  # local binary pattern
        center = img[x][y]

        val_ar = []

        # top_left
        val_ar.append(get_pixel(img, center, x - 1, y - 1))

        # top
        val_ar.append(get_pixel(img, center, x - 1, y))

        # top_right
        val_ar.append(get_pixel(img, center, x - 1, y + 1))

        # right
        val_ar.append(get_pixel(img, center, x, y + 1))

        # bottom_right
        val_ar.append(get_pixel(img, center, x + 1, y + 1))

        # bottom
        val_ar.append(get_pixel(img, center, x + 1, y))

        # bottom_left
        val_ar.append(get_pixel(img, center, x + 1, y - 1))

        # left
        val_ar.append(get_pixel(img, center, x, y - 1))

        # Now, we need to convert binary
        # values to decimal
        power_val = [1, 2, 4, 8, 16, 32, 64, 128]
        val = 0
        for i in range(len(val_ar)):
            val += val_ar[i] * power_val[i]
        return val
    height, width = result.shape
    img_lgbp = np.zeros((height, width),  # LGBP(Local Gabor Binary Pattern)
                        np.uint8)

    for i in range(0, height):
        for j in range(0, width):
            img_lgbp[i, j] = lbp_calculated_pixel(result, i, j)
    lgbp = cv2.calcHist([img_lgbp], [0], None, [50], [0, 50])
    lgbp = lgbp.flatten()
    return lgbp,img_lgbp