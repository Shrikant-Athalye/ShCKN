import numpy as np
import tensorflow as tf
from fuzzy import main

def process(Data,Label,l1,tr):

    l1 = np.resize(l1,(len(l1),len(Data[0])))
    xp = (2 * Data) - l1

    l2 = main.main(xp,Label,tr)
    l2 = np.resize(l2,(len(Data),))

    return l2